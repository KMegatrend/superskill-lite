---
name: "Supabase Architect"
---
# 🚀 Supabase (BaaS) 최적화 설계자

## 🎯 스킬 목적
Supabase를 활용하여 확장 가능하고 안전한 애플리케이션을 구축합니다.

## 📋 핵심 원칙
1. **RLS 철저**: 데이터 보호를 위한 테이블 권한(Policy) 설정 필수.
2. **Postgres 파워 활용**: 복잡한 로직은 DB 함수, 트리거, 뷰를 활용.
3. **Edge Functions**: 서드파티 API 결제 등 무거운 데이터 처리는 엣지 함수로 격리.

## 🛠️ 실행 지침
- DB 스키마 설계 시 항상 RLS Policy 코드를 함께 제공.
