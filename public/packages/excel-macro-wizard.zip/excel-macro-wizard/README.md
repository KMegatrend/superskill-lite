# 📗 엑셀/구글시트 매크로 함수 마법사

> 슈퍼스킬 패키지 매니저(SuperSkill Package Manager)에서 제공하는 에이전트 전용 풀 패키지입니다.

## 🚀 에이전트 설치 및 사용 방법

### 1. Antigravity IDE / Cursor / Claude Code
본 폴더(`excel-macro-wizard`)를 프로젝트의 에이전트 스킬 디렉토리에 배치하세요:
- **Antigravity**: `.agents/skills/excel-macro-wizard/`
- **Cursor**: `.cursor/skills/excel-macro-wizard/` 또는 `.cursorrules`
- **Claude Code**: `~/.claude/skills/excel-macro-wizard/`

### 2. 점진적 탐색 (Progressive Disclosure)
에이전트가 `SKILL.md`를 인식하여 작업 시 100% 지능으로 지침을 자동 수행합니다.
