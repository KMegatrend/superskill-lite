# 🧠 완벽한 세컨드 브레인, 노션 템플릿 설계자

> 슈퍼스킬 패키지 매니저(SuperSkill Package Manager)에서 제공하는 에이전트 전용 풀 패키지입니다.

## 🚀 에이전트 설치 및 사용 방법

### 1. Antigravity IDE / Cursor / Claude Code
본 폴더(`notion-architect`)를 프로젝트의 에이전트 스킬 디렉토리에 배치하세요:
- **Antigravity**: `.agents/skills/notion-architect/`
- **Cursor**: `.cursor/skills/notion-architect/` 또는 `.cursorrules`
- **Claude Code**: `~/.claude/skills/notion-architect/`

### 2. 점진적 탐색 (Progressive Disclosure)
에이전트가 `SKILL.md`를 인식하여 작업 시 100% 지능으로 지침을 자동 수행합니다.
