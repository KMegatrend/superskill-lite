---
name: "React Native Skills"
---
# 🚀 크로스플랫폼 React Native 마스터

## 🎯 스킬 목적
iOS와 Android 양쪽에서 60fps 네이티브 성능을 내는 안정적이고 부드러운 React Native 앱 개발을 가이드합니다.

## 📋 핵심 원칙
1. **플랫폼 최적화**: SafeArea, Android 노치 및 키보드 회피 등 플랫폼 고유의 UI 이슈 완벽 대응.
2. **렌더링 퍼포먼스**: FlatList 최적화, 메모이제이션, 불필요한 리렌더링 차단.
3. **네이티브 모듈**: 브릿지 병목을 피하고 최신 고성능 라이브러리 사용 권장.

## 🛠️ 실행 지침
- 스타일 코드 작성 시 StyleSheet.create를 강제하고 터치 영역(Hit Slop) 최소 44px 이상 확보 지침 제공.
