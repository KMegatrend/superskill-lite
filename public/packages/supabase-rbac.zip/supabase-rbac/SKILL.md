---
name: "supabase-rbac"
description: "데이터베이스 및 Supabase 전문가를 위한 데이터 모델링 가이드라인"
tags:
  - database
  - supabase
  - sql
---

# 🚀 supabase-rbac 마스터 가이드라인

## 🎯 스킬 목적
이 스킬은 **supabase-rbac** (DB 스키마 설계, Supabase 연동, 마이그레이션 등) 관련 작업을 할 때 데이터 무결성과 압도적인 읽기/쓰기 성능을 달성하기 위한 지침입니다.

## 📋 핵심 아키텍처 원칙 (Database)
1. **정규화 및 반정규화**: 중복 데이터를 최소화하기 위해 기본적으로 3정규화(3NF)를 따르되, 읽기 성능이 매우 중요한 지점에서는 의도적인 반정규화나 Materialized View를 활용하세요.
2. **인덱스 최적화**: WHERE 조건, JOIN, ORDER BY에 자주 사용되는 컬럼에는 반드시 적절한 인덱스(B-Tree, GIN 등)를 생성하세요. 단, 과도한 인덱스는 쓰기 성능을 저하시키므로 균형을 맞추세요.
3. **Supabase & RLS (Row Level Security)**: Supabase를 사용할 경우 데이터베이스 접근을 클라이언트에서 직접 허용할 수 있으므로, 반드시 모든 테이블에 엄격한 RLS 정책을 설정하여 타인의 데이터 접근을 차단하세요.
4. **외래키(FK) 및 제약조건**: 데이터 무결성을 위해 참조 무결성(ON DELETE CASCADE/SET NULL 등)과 필수 제약조건(NOT NULL, UNIQUE, CHECK)을 데이터베이스 레벨에서 강제하세요.

## 🛠️ 실행 지침 (AI Prompt)
- 새로운 테이블을 설계할 때는 사용자에게 ERD(개체 관계도) 개념의 마크다운 표를 먼저 제시하여 승인을 받은 후 마이그레이션 스크립트를 작성하세요.
- ORM(Prisma, Drizzle 등)을 사용할 때는 생성되는 실제 SQL 쿼리가 무엇인지 예측하고 비효율적인 쿼리가 발생하지 않도록 주의하세요.

## 💡 필수 자가 검토 (Self-Review)
- [ ] 삭제 로직은 Hard Delete가 아닌 Soft Delete(deleted_at 컬럼)를 고려했는가?
- [ ] RLS 정책이 인증된 사용자(auth.uid())에게만 안전하게 열려 있는가?
- [ ] 타임존(Timezone) 처리는 항상 UTC 기준으로 저장되도록 설계했는가?
