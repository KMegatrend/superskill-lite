---
name: "stripe-webhooks"
description: "백엔드 및 API 아키텍처를 위한 최고 수준의 가이드라인"
tags:
  - backend
  - api
  - architecture
---

# 🚀 stripe-webhooks 백엔드 가이드라인

## 🎯 스킬 목적
이 스킬은 **stripe-webhooks** 관련 백엔드/API 작업을 수행할 때, 안정성, 확장성, 보안성이 담보된 엔터프라이즈급 코드를 생성하기 위한 엄격한 규칙입니다.

## 📋 핵심 아키텍처 원칙 (Backend)
1. **RESTful/GraphQL 표준 준수**: 명확한 리소스 명명 규칙과 올바른 HTTP 메서드(GET, POST, PUT, DELETE) 및 상태 코드(200, 201, 400, 401, 403, 404, 500)를 엄격하게 사용하세요.
2. **레이어드 아키텍처(Layered Architecture)**: 라우터(Controller), 비즈니스 로직(Service), 데이터베이스 접근(Repository) 계층을 분리하여 결합도를 낮추세요.
3. **데이터 유효성 검사 (Validation)**: Zod, Joi 등을 활용해 클라이언트로부터 들어오는 모든 입력값을 최상단 라우터 레벨에서 검증하세요. (절대 DB 쿼리까지 잘못된 값이 도달하게 하지 마세요.)
4. **에러 핸들링**: 모든 에러는 중앙 집중식 에러 핸들러(Middleware)를 통해 처리하고, 클라이언트에게 내부 서버의 스택 트레이스(Stack trace)가 노출되지 않도록 안전하게 정제하세요.

## 🛠️ 실행 지침 (AI Prompt)
- 데이터베이스 쿼리를 작성할 때는 N+1 문제를 방지하고, 쿼리 실행 계획(인덱스 등)을 고려하여 최적화하세요.
- 트랜잭션(Transaction)이 필요한 로직(결제, 재고 차감 등)은 반드시 ACID 속성을 보장하도록 작성하세요.
- 비동기 작업(Promise) 처리 시 `try-catch` 블록을 꼼꼼하게 구성하세요.

## 💡 필수 자가 검토 (Self-Review)
- [ ] 모든 API 엔드포인트에 인증/인가(Auth/Role) 로직이 적용되어 있는가?
- [ ] 대량의 데이터를 응답할 때 페이지네이션(Pagination)이 적용되었는가?
- [ ] API 응답 속도를 높이기 위한 캐싱(Redis 등) 전략이 고려되었는가?
