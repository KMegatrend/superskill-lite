---
name: "playwright-testing"
description: "테스트, 품질 보증(QA) 및 보안 검증을 위한 무결성 가이드라인"
tags:
  - testing
  - qa
  - security
---

# 🚀 playwright-testing 품질/보안 가이드라인

## 🎯 스킬 목적
이 스킬은 **playwright-testing** 관련 테스트 코드 작성, 보안 감사, CI/CD 구축 시 버그 발생 확률을 0%에 수렴시키고 해킹 공격으로부터 시스템을 방어하기 위한 지침입니다.

## 📋 핵심 아키텍처 원칙 (Testing & Security)
1. **TDD 및 테스트 커버리지**: 비즈니스 핵심 로직과 유틸리티 함수에 대해 우선적으로 단위 테스트(Unit Test)를 작성하세요. (Jest, Vitest 활용)
2. **E2E 테스트 (Playwright/Cypress)**: 사용자의 핵심 흐름(회원가입, 결제 등)은 브라우저 렌더링 레벨에서 철저히 E2E 테스트를 작성하여 회귀 버그(Regression)를 방어하세요.
3. **OWASP Top 10 방어**: SQL Injection, XSS, CSRF 공격을 방지하기 위한 보안 처리(Sanitization, CSRF Token, Secure Cookie 등)를 코드 레벨에서 강제하세요.
4. **정적 분석 (Static Analysis)**: ESLint, Prettier, TypeScript의 strict 모드를 활성화하여 컴파일/빌드 타임에 에러를 최대한 잡아내세요.

## 🛠️ 실행 지침 (AI Prompt)
- 새로운 기능을 추가한 후 "테스트 코드를 작성하라"는 명령이 없어도 스스로 어떤 테스트가 필요한지 사용자에게 제안하세요.
- 비밀번호 등 민감 정보는 절대로 평문으로 저장하거나 로그(console.log)에 남기지 말고 철저히 마스킹/해싱 처리하세요.

## 💡 필수 자가 검토 (Self-Review)
- [ ] 엣지 케이스(Edge case - null, undefined, 빈 배열, 아주 큰 값 등)에 대한 테스트가 포함되었는가?
- [ ] 입력 폼(Form)에서 발생할 수 있는 악의적인 스크립트 주입(XSS)을 방어했는가?
- [ ] API Rate Limiting이나 인증 재시도 공격(Brute Force)에 대한 방어 로직이 있는가?
