---
name: "cloudflare-pages"
description: "프론트엔드 및 React/Next.js 전문가를 위한 최고 수준의 가이드라인"
tags:
  - frontend
  - react
  - nextjs
---

# 🚀 cloudflare-pages 전문가 가이드라인

## 🎯 스킬 목적
이 스킬은 **cloudflare-pages** 관련 프론트엔드 작업을 수행할 때, AI(Claude)가 반드시 지켜야 할 웹에이전시급 프로덕션 표준을 강제합니다. 단순한 동작을 넘어 유지보수성과 성능이 극대화된 코드를 작성해야 합니다.

## 📋 핵심 아키텍처 원칙 (Frontend)
1. **컴포넌트 분리**: 하나의 파일이 150줄을 넘지 않도록 논리적으로 분리합니다. UI 컴포넌트와 비즈니스 로직(Custom Hook)을 철저히 분리하세요.
2. **Server/Client 컴포넌트**: Next.js App Router 환경에서는 기본적으로 Server Component를 사용하고, 상호작용(onClick, useState 등)이 필요한 최소한의 하위 트리만 `"use client"`로 선언합니다.
3. **상태 관리 최적화**: 전역 상태(Zustand 등)의 남용을 피하고, 로컬 상태와 서버 상태(SWR/React Query 등)를 명확히 구분하세요.
4. **렌더링 성능**: 불필요한 리렌더링을 막기 위해 `useMemo`, `useCallback`, `React.memo`를 적재적소에 사용하고, 의존성 배열(deps)을 완벽하게 관리하세요.

## 🛠️ 실행 지침 (AI Prompt)
- 코드를 작성하기 전에 사용자에게 "이 컴포넌트가 어디서 재사용될지" 먼저 물어보고 설계를 확정하세요.
- 접근성(a11y) 속성(aria-*, role 등)을 기본적으로 포함하세요.
- 에러 바운더리(Error Boundary)와 서스펜스(Suspense)를 활용한 로딩/에러 상태 UI를 반드시 구현하세요.

## 💡 필수 자가 검토 (Self-Review)
- [ ] 반응형(Mobile-first) 디자인이 고려되었는가?
- [ ] 하드코딩된 문자열 대신 상수(Constants) 파일이나 다국어(i18n) 대응 구조를 썼는가?
- [ ] 콘솔 에러나 React 경고(Warning)를 유발할 요소는 없는가?
